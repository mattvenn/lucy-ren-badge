\ ![logo](badge.png)

# PCB layout for Lucy & Ren badge

\ ![overview](auto-fab/lucy-ren-badge-overview.png)

# Configuration

* 72.3 x 50.7mm
* 1.6 mm FR4, black silkscreen, red. if not available with black silk then green mask
* 2 layers, 35um copper
* generated on 2019-08-23 19:57:40.805207, git version 2129700
